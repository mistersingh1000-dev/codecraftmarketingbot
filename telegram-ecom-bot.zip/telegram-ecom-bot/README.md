# 🛒 Telegram Ecommerce Bot
### Production-Ready Digital Products Store

A complete Telegram bot system for selling digital products, subscriptions, bundles, and services. Powered by Google Sheets as the admin database.

---

## ✨ Features

- **Two product types**: Instant Delivery & Manual Approval
- **Google Sheets database**: Manage everything without code changes
- **Dynamic product catalog**: Categories, plans, images, badges
- **Payment integration**: SuperProfile + UPI fallback
- **Auto delivery**: Files, Drive links, Channel invites, License keys
- **Admin panel**: Approve/reject orders via Telegram
- **Coupon system**: Percentage and flat discounts
- **Order tracking**: Full order history per user
- **Analytics**: Daily revenue and order tracking
- **Security**: Webhook verification, rate limiting, admin-only commands
- **Scalable**: Webhook architecture, caching, modular code

---

## 🗂 Project Structure

```
telegram-ecom-bot/
├── src/
│   ├── index.js              ← App entry point
│   ├── bot.js                ← Bot setup, all handlers registered
│   ├── config/
│   │   └── config.js         ← All configuration
│   ├── commands/
│   │   ├── start.js          ← /start command
│   │   └── admin.js          ← Admin commands
│   ├── handlers/
│   │   ├── shop.js           ← Product browsing
│   │   └── orders.js         ← Order placement & history
│   ├── services/
│   │   ├── payment.js        ← Payment link generation
│   │   └── delivery.js       ← Product delivery
│   ├── middlewares/
│   │   └── auth.js           ← Rate limiting, admin guard
│   ├── database/
│   │   └── sheets.js         ← Google Sheets CRUD
│   ├── utils/
│   │   └── helpers.js        ← Formatters, utilities
│   └── webhooks/
│       └── webhook.js        ← Payment webhook + web pages
├── docs/
│   └── google-sheets-template.md
├── .env.example
├── package.json
└── README.md
```

---

## 🚀 Complete Setup Guide

### STEP 1: Create Telegram Bot

1. Open Telegram and search for **@BotFather**
2. Send `/newbot`
3. Enter a name: `Digital Products Store`
4. Enter a username: `YourStoreName_bot`
5. **Copy the BOT TOKEN** — looks like: `123456789:ABCdef...`
6. Send `/setcommands` to BotFather and set:
   ```
   start - Start the bot
   myorders - View my orders
   support - Contact support
   coupon - Apply coupon code
   ```

### STEP 2: Get Your Telegram User ID (for admin)

1. Search for **@userinfobot** on Telegram
2. Send `/start`
3. Note your **numeric ID** (e.g., `123456789`)

### STEP 3: Create Private Media Channel

This channel stores your delivery files and product images.

1. Create a new private Telegram channel
2. Add your bot as an **admin** with post/read permissions
3. Get the channel ID:
   - Forward any message from the channel to **@userinfobot**
   - The channel ID will be shown (format: `-100xxxxxxxxxx`)

### STEP 4: Set Up Google Sheets

#### 4a. Create the Sheet
1. Go to [sheets.google.com](https://sheets.google.com)
2. Create a new spreadsheet
3. Name it "Telegram Bot Database"
4. Create 6 tabs: `Products`, `Orders`, `Admins`, `Coupons`, `Settings`, `Analytics`
5. Copy headers from `/docs/google-sheets-template.md`
6. Add example data from the template

#### 4b. Get Sheet ID
The Sheet ID is in the URL:
```
https://docs.google.com/spreadsheets/d/YOUR_SHEET_ID_HERE/edit
```

#### 4c. Create Google Service Account

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project (or use existing)
3. Go to **APIs & Services → Library**
4. Search "Google Sheets API" → Enable it
5. Go to **APIs & Services → Credentials**
6. Click **Create Credentials → Service Account**
7. Name it `telegram-bot-sheets`
8. Click through → Done
9. Click on the service account → **Keys** tab
10. **Add Key → Create new key → JSON**
11. Download the JSON file

From the JSON file, copy:
- `client_email` → this is your `GOOGLE_SERVICE_ACCOUNT_EMAIL`
- `private_key` → this is your `GOOGLE_PRIVATE_KEY`

#### 4d. Share Sheet with Service Account

1. Open your Google Sheet
2. Click **Share** (top right)
3. Paste the service account email
4. Give **Editor** access
5. Click Send

### STEP 5: Set Up SuperProfile Payment (Optional)

1. Register at [superprofile.bio](https://superprofile.bio)
2. Set up your store
3. Get your **API Key** and **Store ID** from settings
4. Set webhook URL in SuperProfile:
   ```
   https://your-app.onrender.com/webhook/payment
   ```

If you don't use SuperProfile, the bot falls back to UPI link generation.

### STEP 6: Configure Environment Variables

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Edit `.env` and fill in all values:
   ```env
   BOT_TOKEN=123456789:ABCdef...
   ADMIN_IDS=123456789
   SUPPORT_USERNAME=yourusername
   MEDIA_CHANNEL_ID=-100123456789
   
   WEBHOOK_DOMAIN=https://your-app.onrender.com
   WEBHOOK_SECRET=make_this_a_long_random_string
   
   GOOGLE_SHEET_ID=your_sheet_id
   GOOGLE_SERVICE_ACCOUNT_EMAIL=bot@project.iam.gserviceaccount.com
   GOOGLE_PRIVATE_KEY="-----BEGIN RSA PRIVATE KEY-----\nKEY HERE\n-----END RSA PRIVATE KEY-----\n"
   ```

### STEP 7: Get Product Image File IDs

1. Start your bot in development mode first (`npm run dev`)
2. Send `/getfileid` to your bot
3. Upload a product image
4. Bot replies with the `file_id`
5. Copy the file_id into the `ImageFileID` column in Google Sheets

### STEP 8: Install Dependencies

```bash
npm install
```

### STEP 9: Test Locally

```bash
npm run dev
```

Test by opening your bot in Telegram and sending `/start`.

---

## 🌐 Deployment

### Option A: Render (Recommended — Free Tier Available)

1. Push your code to GitHub
2. Go to [render.com](https://render.com) → New → Web Service
3. Connect your GitHub repo
4. Configure:
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Environment**: Node
5. Add all environment variables from `.env`
6. Set `NODE_ENV=production`
7. Deploy!
8. Copy your Render URL (e.g., `https://your-bot.onrender.com`)
9. Set `WEBHOOK_DOMAIN` to your Render URL

### Option B: Railway

1. Install Railway CLI: `npm i -g @railway/cli`
2. Login: `railway login`
3. Initialize: `railway init`
4. Add env vars: `railway variables set KEY=value`
5. Deploy: `railway up`

### Option C: VPS (Ubuntu)

```bash
# Install Node.js 18+
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2
npm install -g pm2

# Clone your repo
git clone https://github.com/yourusername/telegram-ecom-bot.git
cd telegram-ecom-bot

# Install dependencies
npm install

# Create .env file
nano .env
# (paste your env vars)

# Start with PM2
pm2 start src/index.js --name telegram-bot
pm2 save
pm2 startup

# Set up Nginx reverse proxy (optional)
sudo apt install nginx
# Add reverse proxy config for your domain
```

---

## 🔧 Admin Guide

### Bot Commands

| Command | Access | Description |
|---------|--------|-------------|
| `/start` | All users | Show main menu |
| `/myorders` | All users | View order history |
| `/coupon <CODE>` | All users | Apply coupon |
| `/support` | All users | Show support info |
| `/admin` | Admin only | Admin dashboard |
| `/orders` | Admin only | View pending orders |
| `/stats` | Admin only | Revenue statistics |
| `/broadcast` | Admin only | Send message to users |
| `/getfileid` | Admin only | Get file_id for Google Sheets |

### Processing Orders

When a manual approval order is placed, you receive:
```
🛒 New Order Request

👤 User: @username
🆔 User ID: 123456789
📦 Product: Canva Pro Subscription
🎯 Plan: 1 Month
💰 Price: ₹299
🆔 Order ID: ORD-xxx
📅 Date: 2024-01-15 10:30:00

[✅ Approve] [❌ Reject]
[⏳ Waiting] [📦 Delivered]
```

Click the appropriate button. Customer is automatically notified.

### Adding Products

1. Open Google Sheet → Products tab
2. Add a new row
3. Fill all columns (refer to docs/google-sheets-template.md)
4. Set `ActiveStatus = TRUE`
5. Cache auto-refreshes every 5 minutes, or admin can refresh manually

### Managing Stock

- `Available` → Normal product display with buy button
- `Limited` → Shows 🔥 badge, buy button still works
- `OutOfStock` → Shows ❌ badge, buy button disabled

---

## 💡 How the Payment Flow Works

### Instant Delivery Flow:
```
User clicks Buy → Payment link generated → User pays
→ Webhook received (or manual confirm) → Product delivered instantly
```

### Manual Approval Flow:
```
User clicks Buy → Payment link generated → User pays
→ Webhook received → Admin notified → Admin clicks Approve/Delivered
→ Customer notified → Product delivered
```

---

## 🛡 Security Features

- **Webhook signature verification**: Validates all payment webhooks
- **Rate limiting**: 30 actions/minute per user, 100 requests/minute on API
- **Admin-only routes**: All admin commands check Telegram user ID
- **Session isolation**: Each user has their own session state
- **No plaintext secrets**: All sensitive data in environment variables

---

## 🔄 How Google Sheets Integration Works

1. Bot uses service account credentials to authenticate with Google Sheets API v4
2. Products are read on demand with 5-minute caching for performance
3. Orders are written immediately with no caching
4. Admin updates rows directly using column-matching logic
5. Cache can be cleared by admin via `/admin → Refresh Cache`

---

## 📞 Support

Built with ❤️ for digital product sellers.

For customization or support, contact your developer.
