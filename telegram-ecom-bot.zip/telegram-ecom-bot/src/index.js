require('dotenv').config();
const express = require('express');
const rateLimit = require('express-rate-limit');
const { createBot } = require('./bot');
const { router: webhookRouter, setBot } = require('./webhooks/webhook');
const config = require('./config/config');

// ── Validate required environment variables ──────────────────────────────────
function validateEnv() {
  const required = ['BOT_TOKEN', 'GOOGLE_SHEET_ID', 'GOOGLE_SERVICE_ACCOUNT_EMAIL', 'GOOGLE_PRIVATE_KEY'];
  const missing = required.filter(k => !process.env[k]);
  if (missing.length > 0) {
    console.error('❌ Missing required environment variables:', missing.join(', '));
    process.exit(1);
  }
}

async function main() {
  validateEnv();

  // ── Create bot ─────────────────────────────────────────────────────────────
  const bot = createBot();
  setBot(bot);

  // ── Create Express app ─────────────────────────────────────────────────────
  const app = express();

  // Rate limiting
  const limiter = rateLimit({
    windowMs: 60 * 1000,
    max: 100,
    message: 'Too many requests',
  });
  app.use(limiter);

  // Register webhook routes (must come before express.json() for raw body access)
  app.use('/', webhookRouter);

  // JSON body parser for other routes
  app.use(express.json());

  const { port, webhookDomain, webhookSecret, nodeEnv } = config.server;

  if (nodeEnv === 'production' && webhookDomain) {
    // ── Webhook mode (production) ────────────────────────────────────────────
    const webhookPath = `/bot${webhookSecret}`;

    app.use(bot.webhookCallback(webhookPath));

    await bot.telegram.setWebhook(`${webhookDomain}${webhookPath}`);
    console.log(`✅ Webhook set: ${webhookDomain}${webhookPath}`);

    app.listen(port, () => {
      console.log(`🚀 Server running on port ${port}`);
      console.log(`📡 Bot running in webhook mode`);
    });

  } else {
    // ── Long polling mode (development) ─────────────────────────────────────
    await bot.telegram.deleteWebhook();
    bot.launch();
    console.log(`🤖 Bot running in polling mode`);

    app.listen(port, () => {
      console.log(`🚀 Server running on port ${port}`);
    });
  }

  // ── Graceful shutdown ──────────────────────────────────────────────────────
  process.once('SIGINT', () => bot.stop('SIGINT'));
  process.once('SIGTERM', () => bot.stop('SIGTERM'));
}

main().catch(err => {
  console.error('❌ Failed to start bot:', err);
  process.exit(1);
});
