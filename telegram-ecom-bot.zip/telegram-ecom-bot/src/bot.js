const { Telegraf, Markup, session } = require('telegraf');
const config = require('./config/config');
const { userMiddleware, rateLimitMiddleware, adminOnly, errorHandler } = require('./middlewares/auth');
const { startCommand } = require('./commands/start');
const { adminCommand, ordersCommand, statsCommand, broadcastCommand, handleAdminAction } = require('./commands/admin');
const { showCategories, showCategoryProducts, showProduct, showFeatured, showOffers, showSupport } = require('./handlers/shop');
const { handleBuyClick, handlePaymentConfirm, handleCancelOrder, showMyOrders, handleCouponInput } = require('./handlers/orders');

function createBot() {
  const bot = new Telegraf(config.telegram.token);

  // ── Session middleware ──────────────────────────────────────────────────────
  bot.use(session());

  // ── Custom middleware ───────────────────────────────────────────────────────
  bot.use(userMiddleware);
  bot.use(rateLimitMiddleware);

  // ── Error handling ──────────────────────────────────────────────────────────
  bot.catch(errorHandler);

  // ════════════════════════════════════════════════════════════
  // COMMANDS
  // ════════════════════════════════════════════════════════════

  bot.command('start', startCommand);
  bot.command('menu', startCommand);

  // Admin commands (protected)
  bot.command('admin', userMiddleware, adminOnly, adminCommand);
  bot.command('orders', userMiddleware, adminOnly, ordersCommand);
  bot.command('stats', userMiddleware, adminOnly, statsCommand);
  bot.command('broadcast', userMiddleware, adminOnly, broadcastCommand);

  // User commands
  bot.command('myorders', showMyOrders);
  bot.command('support', async (ctx) => {
    ctx.callbackQuery = { data: 'menu_support' };
    await showSupport(ctx);
  });

  bot.command('coupon', async (ctx) => {
    const code = ctx.message.text.split(' ')[1];
    if (!code) return ctx.reply('Usage: /coupon <CODE>');
    await handleCouponInput(ctx, code);
  });

  // ── Get file_id helper (admin only) ──────────────────────────────────────
  bot.command('getfileid', userMiddleware, adminOnly, async (ctx) => {
    await ctx.reply(
      '📎 Forward or upload a file/photo to this bot and I will reply with its file_id.\n\n<i>Use this to populate the ImageFileID column in your Google Sheet.</i>',
      { parse_mode: 'HTML' }
    );
    ctx.session = { ...ctx.session, awaitingFile: true };
  });

  // ════════════════════════════════════════════════════════════
  // CALLBACK QUERIES (Inline Button Clicks)
  // ════════════════════════════════════════════════════════════

  bot.on('callback_query', async (ctx) => {
    const data = ctx.callbackQuery?.data;
    if (!data) return ctx.answerCbQuery();

    try {
      // ── Main menu ────────────────────────────────────────────────────────
      if (data === 'menu_main') {
        await ctx.answerCbQuery();
        return startCommand(ctx);
      }

      if (data === 'menu_browse') return showCategories(ctx);
      if (data === 'menu_featured') return showFeatured(ctx);
      if (data === 'menu_orders') return showMyOrders(ctx);
      if (data === 'menu_offers') return showOffers(ctx);
      if (data === 'menu_support') return showSupport(ctx);

      // ── Category selection ───────────────────────────────────────────────
      if (data.startsWith('cat_')) {
        const category = decodeURIComponent(data.replace('cat_', ''));
        return showCategoryProducts(ctx, category);
      }

      // ── Product view ─────────────────────────────────────────────────────
      if (data.startsWith('product_')) {
        const productId = data.replace('product_', '');
        return showProduct(ctx, productId);
      }

      // ── Buy / purchase flow ──────────────────────────────────────────────
      if (data.startsWith('buy_')) {
        return handleBuyClick(ctx, bot);
      }

      // ── Payment confirmation ─────────────────────────────────────────────
      if (data.startsWith('confirm_payment_')) {
        return handlePaymentConfirm(ctx, bot);
      }

      // ── Cancel order ─────────────────────────────────────────────────────
      if (data.startsWith('cancel_order_')) {
        return handleCancelOrder(ctx);
      }

      // ── Unavailable product ──────────────────────────────────────────────
      if (data.startsWith('unavailable_')) {
        return ctx.answerCbQuery('❌ This product is currently out of stock.', { show_alert: true });
      }

      // ── Admin actions ────────────────────────────────────────────────────
      if (data.startsWith('admin_')) {
        if (!ctx.isAdmin) return ctx.answerCbQuery('⛔ Admin only.');
        return handleAdminAction(ctx, bot);
      }

      await ctx.answerCbQuery();
    } catch (err) {
      console.error('[Bot] Callback error:', err.message);
      await ctx.answerCbQuery('Something went wrong.').catch(() => {});
    }
  });

  // ════════════════════════════════════════════════════════════
  // MESSAGE HANDLERS
  // ════════════════════════════════════════════════════════════

  // ── Admin broadcast message handler ──────────────────────────────────────
  bot.on('text', async (ctx) => {
    const text = ctx.message.text;

    // Cancel command
    if (text === '/cancel') {
      if (ctx.session) ctx.session = {};
      return ctx.reply('✅ Action cancelled.');
    }

    // Admin broadcast flow
    if (ctx.isAdmin && ctx.session?.awaitingBroadcast) {
      ctx.session.awaitingBroadcast = false;
      await ctx.reply('📢 Broadcasting message... (implement user list fetch from your database)');
      // In a full implementation, you'd fetch all user IDs and send to each
      // For now, we confirm the feature is ready
      return;
    }

    // Default: show main menu for unrecognized messages
    if (!text.startsWith('/')) {
      return startCommand(ctx);
    }
  });

  // ── File ID helper for admin ──────────────────────────────────────────────
  bot.on(['photo', 'document', 'video', 'audio'], async (ctx) => {
    if (!ctx.isAdmin) return;

    let fileId = '';
    let fileType = '';

    if (ctx.message.photo) {
      const photos = ctx.message.photo;
      fileId = photos[photos.length - 1].file_id;
      fileType = 'photo';
    } else if (ctx.message.document) {
      fileId = ctx.message.document.file_id;
      fileType = 'document';
    } else if (ctx.message.video) {
      fileId = ctx.message.video.file_id;
      fileType = 'video';
    } else if (ctx.message.audio) {
      fileId = ctx.message.audio.file_id;
      fileType = 'audio';
    }

    if (fileId) {
      await ctx.reply(
        `📎 <b>File ID</b> (${fileType})\n\n<code>${fileId}</code>\n\nCopy this into the <b>ImageFileID</b> column in Google Sheets.`,
        { parse_mode: 'HTML' }
      );
    }
  });

  return bot;
}

module.exports = { createBot };
