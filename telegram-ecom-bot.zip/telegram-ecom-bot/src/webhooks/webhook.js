const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const sheets = require('../database/sheets');
const delivery = require('../services/delivery');
const payment = require('../services/payment');
const helpers = require('../utils/helpers');
const config = require('../config/config');

let botInstance = null;

function setBot(bot) {
  botInstance = bot;
}

// ── SuperProfile / Payment webhook ──────────────────────────────────────────
router.post('/webhook/payment', express.raw({ type: 'application/json' }), async (req, res) => {
  const signature = req.headers['x-superprofile-signature'] || req.headers['x-signature'] || '';
  const rawBody = req.body;

  // Verify signature
  if (!payment.verifyWebhookSignature(rawBody, signature)) {
    console.warn('[Webhook] Invalid signature');
    return res.status(401).json({ error: 'Invalid signature' });
  }

  let body;
  try {
    body = JSON.parse(rawBody.toString());
  } catch {
    return res.status(400).json({ error: 'Invalid JSON' });
  }

  const { orderId, transactionId, status, amount } = payment.parseWebhookPayload(body);

  if (!orderId) {
    return res.status(400).json({ error: 'Missing order_id' });
  }

  console.log(`[Webhook] Payment event: order=${orderId} status=${status}`);

  try {
    const order = await sheets.getOrderById(orderId);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    if (status === 'paid' || status === 'success' || status === 'PAID') {
      // Prevent duplicate processing
      if (order.PaymentStatus === config.paymentStatus.PAID) {
        return res.json({ message: 'Already processed' });
      }

      await sheets.updateOrder(orderId, {
        PaymentStatus: config.paymentStatus.PAID,
        TransactionID: transactionId || '',
        UpdatedAt: helpers.nowISO(),
      });

      const product = await sheets.getProductById(order.ProductID);
      if (!product) throw new Error('Product not found for order ' + orderId);

      const userId = parseInt(order.TelegramUserID);

      if (product.ProductType === config.productTypes.INSTANT) {
        // Auto-deliver
        const result = await delivery.deliverProduct(botInstance, userId, product, order);
        if (result.success) {
          await sheets.updateOrder(orderId, {
            OrderStatus: config.orderStatus.DELIVERED,
            DeliveryStatus: 'Delivered',
            UpdatedAt: helpers.nowISO(),
          });
        }
      } else {
        // Mark pending, notify admins
        await sheets.updateOrder(orderId, {
          OrderStatus: config.orderStatus.PENDING,
          UpdatedAt: helpers.nowISO(),
        });

        if (botInstance) {
          const { Markup } = require('telegraf');
          const orderText = helpers.formatOrderForAdmin({ ...order, PaymentStatus: config.paymentStatus.PAID, TransactionID: transactionId });
          const adminButtons = helpers.buildAdminActionButtons(orderId);

          for (const adminId of config.telegram.adminIds) {
            try {
              await botInstance.telegram.sendMessage(adminId, orderText, {
                parse_mode: 'HTML',
                ...Markup.inlineKeyboard(adminButtons),
              });
            } catch {}
          }

          // Notify user
          try {
            await botInstance.telegram.sendMessage(
              userId,
              helpers.getStatusMessage(config.orderStatus.PENDING, product.ProductName),
              { parse_mode: 'HTML' }
            );
          } catch {}
        }
      }

      // Update analytics
      try {
        await sheets.updateAnalytics(helpers.today(), {
          TotalOrders: 1,
          TotalRevenue: parseFloat(order.Price || 0),
          DeliveredOrders: product.ProductType === config.productTypes.INSTANT ? 1 : 0,
          PendingOrders: product.ProductType === config.productTypes.MANUAL ? 1 : 0,
        });
      } catch {}

    } else if (status === 'failed' || status === 'FAILED') {
      await sheets.updateOrder(orderId, {
        PaymentStatus: config.paymentStatus.FAILED,
        UpdatedAt: helpers.nowISO(),
      });

      if (botInstance) {
        try {
          await botInstance.telegram.sendMessage(
            parseInt(order.TelegramUserID),
            `❌ <b>Payment Failed</b>\n\nYour payment for <b>${order.ProductName}</b> failed.\n\nOrder ID: <code>${orderId}</code>\n\nPlease try again or contact @${config.telegram.supportUsername}`,
            { parse_mode: 'HTML' }
          );
        } catch {}
      }
    }

    res.json({ success: true });

  } catch (err) {
    console.error('[Webhook] Processing error:', err);
    res.status(500).json({ error: 'Internal error' });
  }
});

// ── Manual payment confirmation page ─────────────────────────────────────────
router.get('/pay', (req, res) => {
  const { order_id, amount, product, plan, upi } = req.query;
  const sym = config.app.currencySymbol;

  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Payment — ${product || 'Digital Store'}</title>
      <style>
        body { font-family: -apple-system, sans-serif; background: #0a0a0a; color: #fff; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; padding: 20px; box-sizing: border-box; }
        .card { background: #1a1a2e; border: 1px solid #16213e; border-radius: 20px; padding: 30px; max-width: 400px; width: 100%; text-align: center; }
        h1 { color: #e94560; margin-bottom: 5px; font-size: 24px; }
        .amount { font-size: 48px; font-weight: 900; color: #fff; margin: 20px 0; }
        .detail { color: #aaa; margin: 5px 0; }
        .btn { display: block; background: #e94560; color: #fff; text-decoration: none; padding: 16px; border-radius: 12px; font-size: 18px; font-weight: 700; margin: 20px 0 10px; }
        .orderid { font-family: monospace; background: #0f3460; padding: 8px 16px; border-radius: 8px; font-size: 14px; display: inline-block; margin: 10px 0; }
        .note { font-size: 12px; color: #888; margin-top: 20px; }
      </style>
    </head>
    <body>
      <div class="card">
        <h1>💳 Payment</h1>
        <p class="detail">${decodeURIComponent(product || '')} — ${decodeURIComponent(plan || '')}</p>
        <div class="amount">${sym}${amount}</div>
        <div class="orderid">${order_id}</div>
        ${upi ? `<a href="${decodeURIComponent(upi)}" class="btn">📱 Pay via UPI</a>` : ''}
        <p class="note">After payment, return to Telegram and click "I Have Paid" button.</p>
        <p class="note">Order ID: <strong>${order_id}</strong></p>
      </div>
    </body>
    </html>
  `);
});

// ── Payment success page ─────────────────────────────────────────────────────
router.get('/payment/success', (req, res) => {
  res.send(`
    <!DOCTYPE html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><title>Payment Success</title>
    <style>body{font-family:sans-serif;background:#0a0a0a;color:#fff;display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0;text-align:center;padding:20px;box-sizing:border-box;}
    .card{background:#0d2818;border:1px solid #1a5c35;border-radius:20px;padding:40px;max-width:380px;width:100%;}
    h1{color:#4ade80;font-size:32px;} p{color:#aaa;}</style></head>
    <body><div class="card"><h1>✅ Payment Successful!</h1><p>Your payment was received. Return to Telegram to receive your product.</p>
    <p style="color:#888;font-size:12px;">Order ID: ${req.query.order_id || 'N/A'}</p></div></body></html>
  `);
});

// ── Payment failed page ──────────────────────────────────────────────────────
router.get('/payment/failed', (req, res) => {
  res.send(`
    <!DOCTYPE html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><title>Payment Failed</title>
    <style>body{font-family:sans-serif;background:#0a0a0a;color:#fff;display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0;text-align:center;padding:20px;box-sizing:border-box;}
    .card{background:#1a0808;border:1px solid #5c1a1a;border-radius:20px;padding:40px;max-width:380px;width:100%;}
    h1{color:#f87171;font-size:32px;} p{color:#aaa;}</style></head>
    <body><div class="card"><h1>❌ Payment Failed</h1><p>Your payment could not be processed. Please return to Telegram and try again.</p>
    <p style="color:#888;font-size:12px;">Order ID: ${req.query.order_id || 'N/A'}</p></div></body></html>
  `);
});

// ── Health check ─────────────────────────────────────────────────────────────
router.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

module.exports = { router, setBot };
