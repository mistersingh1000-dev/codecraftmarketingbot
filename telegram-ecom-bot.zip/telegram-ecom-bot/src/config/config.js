require('dotenv').config();

const config = {
  telegram: {
    token: process.env.BOT_TOKEN,
    adminIds: (process.env.ADMIN_IDS || '').split(',').map(id => parseInt(id.trim())).filter(Boolean),
    supportUsername: process.env.SUPPORT_USERNAME || 'support',
    mediaChannelId: process.env.MEDIA_CHANNEL_ID,
    botUsername: process.env.BOT_USERNAME,
  },

  server: {
    port: parseInt(process.env.PORT) || 3000,
    webhookDomain: process.env.WEBHOOK_DOMAIN,
    webhookSecret: process.env.WEBHOOK_SECRET || 'default_secret_change_me',
    nodeEnv: process.env.NODE_ENV || 'development',
  },

  google: {
    sheetId: process.env.GOOGLE_SHEET_ID,
    serviceAccountEmail: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
    privateKey: (process.env.GOOGLE_PRIVATE_KEY || '').replace(/\\n/g, '\n'),
  },

  payment: {
    superprofileApiKey: process.env.SUPERPROFILE_API_KEY,
    superprofileStoreId: process.env.SUPERPROFILE_STORE_ID,
    webhookSecret: process.env.SUPERPROFILE_WEBHOOK_SECRET,
    successUrl: process.env.PAYMENT_SUCCESS_URL,
    failedUrl: process.env.PAYMENT_FAILED_URL,
  },

  app: {
    currencySymbol: process.env.CURRENCY_SYMBOL || '₹',
    cacheTtl: parseInt(process.env.CACHE_TTL) || 300,
  },

  // Google Sheets tab names
  sheets: {
    products: 'Products',
    orders: 'Orders',
    admins: 'Admins',
    coupons: 'Coupons',
    settings: 'Settings',
    analytics: 'Analytics',
  },

  // Product types
  productTypes: {
    INSTANT: 'Instant',
    MANUAL: 'ManualApproval',
  },

  // Delivery methods
  deliveryMethods: {
    TELEGRAM_FILE: 'TelegramFile',
    DRIVE_LINK: 'DriveLink',
    CHANNEL_INVITE: 'ChannelInvite',
    TEXT_LICENSE: 'TextLicense',
    MANUAL: 'ManualDelivery',
  },

  // Order statuses
  orderStatus: {
    PENDING: 'Pending',
    APPROVED: 'Approved',
    REJECTED: 'Rejected',
    WAITING: 'Waiting',
    DELIVERED: 'Delivered',
    CANCELLED: 'Cancelled',
  },

  // Payment statuses
  paymentStatus: {
    PENDING: 'Pending',
    PAID: 'Paid',
    FAILED: 'Failed',
    REFUNDED: 'Refunded',
  },

  // Stock statuses
  stockStatus: {
    AVAILABLE: 'Available',
    OUT_OF_STOCK: 'OutOfStock',
    LIMITED: 'Limited',
  },
};

module.exports = config;
