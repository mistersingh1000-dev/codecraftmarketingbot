const config = require('../config/config');

// ── Anti-spam: track user message counts ─────────────────────────────────────
const rateLimitMap = new Map();

function isRateLimited(userId) {
  const now = Date.now();
  const key = String(userId);
  const record = rateLimitMap.get(key) || { count: 0, resetAt: now + 60000 };

  if (now > record.resetAt) {
    record.count = 0;
    record.resetAt = now + 60000;
  }

  record.count++;
  rateLimitMap.set(key, record);

  return record.count > 30; // max 30 actions per minute
}

// ── Middleware: add user info to ctx ─────────────────────────────────────────
function userMiddleware(ctx, next) {
  if (ctx.from) {
    ctx.userId = ctx.from.id;
    ctx.username = ctx.from.username || '';
    ctx.fullName = `${ctx.from.first_name || ''} ${ctx.from.last_name || ''}`.trim();
    ctx.isAdmin = config.telegram.adminIds.includes(ctx.from.id);
  }
  return next();
}

// ── Middleware: rate limiting ─────────────────────────────────────────────────
function rateLimitMiddleware(ctx, next) {
  if (!ctx.from) return next();
  if (ctx.isAdmin) return next(); // skip rate limit for admins

  if (isRateLimited(ctx.from.id)) {
    return ctx.reply('⚠️ Too many requests. Please slow down.').catch(() => {});
  }
  return next();
}

// ── Middleware: admin-only guard ──────────────────────────────────────────────
function adminOnly(ctx, next) {
  if (!ctx.isAdmin) {
    return ctx.reply('⛔ This command is for admins only.').catch(() => {});
  }
  return next();
}

// ── Error handler ────────────────────────────────────────────────────────────
function errorHandler(err, ctx) {
  console.error(`[Bot Error] Update ${ctx.update?.update_id}:`, err);
  try {
    ctx.reply('⚠️ Something went wrong. Please try again or contact support.').catch(() => {});
  } catch {}
}

module.exports = { userMiddleware, rateLimitMiddleware, adminOnly, errorHandler };
