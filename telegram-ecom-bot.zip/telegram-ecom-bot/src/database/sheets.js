const { google } = require('googleapis');
const config = require('../config/config');

// ── In-memory cache ──────────────────────────────────────────────────────────
const cache = new Map();

function getCached(key) {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.timestamp > config.app.cacheTtl * 1000) {
    cache.delete(key);
    return null;
  }
  return entry.data;
}

function setCache(key, data) {
  cache.set(key, { data, timestamp: Date.now() });
}

function clearCache(key) {
  if (key) cache.delete(key);
  else cache.clear();
}

// ── Auth ─────────────────────────────────────────────────────────────────────
function getAuth() {
  return new google.auth.JWT(
    config.google.serviceAccountEmail,
    null,
    config.google.privateKey,
    ['https://www.googleapis.com/auth/spreadsheets']
  );
}

function getSheets() {
  return google.sheets({ version: 'v4', auth: getAuth() });
}

// ── Generic read/write helpers ───────────────────────────────────────────────
async function readSheet(sheetName, useCache = true) {
  const cacheKey = `sheet_${sheetName}`;
  if (useCache) {
    const cached = getCached(cacheKey);
    if (cached) return cached;
  }

  const sheets = getSheets();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: config.google.sheetId,
    range: sheetName,
  });

  const rows = res.data.values || [];
  if (rows.length < 2) return [];

  const headers = rows[0];
  const data = rows.slice(1).map(row => {
    const obj = {};
    headers.forEach((h, i) => { obj[h] = row[i] || ''; });
    return obj;
  });

  setCache(cacheKey, data);
  return data;
}

async function appendRow(sheetName, rowData) {
  const sheets = getSheets();
  // Get headers first
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: config.google.sheetId,
    range: `${sheetName}!1:1`,
  });
  const headers = (res.data.values || [[]])[0];
  const row = headers.map(h => rowData[h] !== undefined ? rowData[h] : '');

  await sheets.spreadsheets.values.append({
    spreadsheetId: config.google.sheetId,
    range: sheetName,
    valueInputOption: 'USER_ENTERED',
    resource: { values: [row] },
  });

  clearCache(`sheet_${sheetName}`);
}

async function updateRow(sheetName, matchColumn, matchValue, updates) {
  const sheets = getSheets();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: config.google.sheetId,
    range: sheetName,
  });

  const rows = res.data.values || [];
  if (rows.length < 2) throw new Error('Sheet empty or no data rows');

  const headers = rows[0];
  const matchIdx = headers.indexOf(matchColumn);
  if (matchIdx === -1) throw new Error(`Column "${matchColumn}" not found`);

  // Find the row index (1-based, +1 for header row)
  let rowIdx = -1;
  for (let i = 1; i < rows.length; i++) {
    if (rows[i][matchIdx] === String(matchValue)) {
      rowIdx = i + 1; // sheets row number
      break;
    }
  }
  if (rowIdx === -1) throw new Error(`Row with ${matchColumn}=${matchValue} not found`);

  // Build new row values
  const existing = rows[rowIdx - 1]; // 0-indexed
  const updatedRow = headers.map((h, i) => {
    if (updates[h] !== undefined) return updates[h];
    return existing[i] || '';
  });

  await sheets.spreadsheets.values.update({
    spreadsheetId: config.google.sheetId,
    range: `${sheetName}!A${rowIdx}`,
    valueInputOption: 'USER_ENTERED',
    resource: { values: [updatedRow] },
  });

  clearCache(`sheet_${sheetName}`);
}

// ── Products ─────────────────────────────────────────────────────────────────
async function getProducts(useCache = true) {
  const rows = await readSheet(config.sheets.products, useCache);
  return rows.filter(r => r.ActiveStatus === 'TRUE' || r.ActiveStatus === 'true' || r.ActiveStatus === '1' || r.ActiveStatus === 'Yes');
}

async function getProductsByCategory() {
  const products = await getProducts();
  const categories = {};
  for (const p of products) {
    const cat = p.Category || 'Uncategorized';
    if (!categories[cat]) categories[cat] = [];
    categories[cat].push(p);
  }
  return categories;
}

async function getProductById(productId) {
  const products = await getProducts();
  return products.find(p => p.ProductID === String(productId)) || null;
}

async function getFeaturedProducts() {
  const products = await getProducts();
  return products.filter(p => p.FeaturedProduct === 'TRUE' || p.FeaturedProduct === 'true' || p.FeaturedProduct === '1' || p.FeaturedProduct === 'Yes');
}

// ── Orders ───────────────────────────────────────────────────────────────────
async function createOrder(orderData) {
  await appendRow(config.sheets.orders, orderData);
}

async function getOrderById(orderId) {
  const orders = await readSheet(config.sheets.orders, false);
  return orders.find(o => o.OrderID === String(orderId)) || null;
}

async function getOrdersByUser(userId) {
  const orders = await readSheet(config.sheets.orders, false);
  return orders.filter(o => o.TelegramUserID === String(userId));
}

async function getPendingOrders() {
  const orders = await readSheet(config.sheets.orders, false);
  return orders.filter(o => o.OrderStatus === 'Pending' && o.PaymentStatus === 'Paid');
}

async function updateOrder(orderId, updates) {
  await updateRow(config.sheets.orders, 'OrderID', orderId, updates);
}

// ── Settings ─────────────────────────────────────────────────────────────────
async function getSetting(name) {
  const settings = await readSheet(config.sheets.settings);
  const row = settings.find(s => s.SettingName === name);
  return row ? row.SettingValue : null;
}

// ── Coupons ──────────────────────────────────────────────────────────────────
async function getCoupon(code) {
  const coupons = await readSheet(config.sheets.coupons);
  return coupons.find(c => c.CouponCode === code && c.Status === 'Active') || null;
}

// ── Analytics ────────────────────────────────────────────────────────────────
async function logAnalytics(data) {
  await appendRow(config.sheets.analytics, data);
}

async function updateAnalytics(date, updates) {
  try {
    await updateRow(config.sheets.analytics, 'Date', date, updates);
  } catch {
    // Row doesn't exist yet — create it
    await appendRow(config.sheets.analytics, { Date: date, ...updates });
  }
}

module.exports = {
  readSheet,
  appendRow,
  updateRow,
  clearCache,
  getProducts,
  getProductsByCategory,
  getProductById,
  getFeaturedProducts,
  createOrder,
  getOrderById,
  getOrdersByUser,
  getPendingOrders,
  updateOrder,
  getSetting,
  getCoupon,
  logAnalytics,
  updateAnalytics,
};
