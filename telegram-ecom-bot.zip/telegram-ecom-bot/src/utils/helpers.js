const config = require('../config/config');
const dayjs = require('dayjs');

// ── Format product display message ───────────────────────────────────────────
function formatProductMessage(product) {
  const sym = config.app.currencySymbol;
  const { stockStatus, productTypes } = config;

  const stockBadge = {
    [stockStatus.AVAILABLE]: '✅ Available',
    [stockStatus.OUT_OF_STOCK]: '❌ Out of Stock',
    [stockStatus.LIMITED]: '🔥 Limited Stock',
  }[product.StockStatus] || '✅ Available';

  const typeBadge = product.ProductType === productTypes.INSTANT
    ? '⚡ Instant Delivery'
    : '⏳ Manual Approval';

  const lines = [
    `🛍 <b>${product.ProductName}</b>`,
    ``,
    `${typeBadge}`,
    `${stockBadge}`,
    ``,
    product.ShortDescription ? `📝 ${product.ShortDescription}` : null,
    ``,
    product.Tags ? `🏷 <i>${product.Tags}</i>` : null,
  ].filter(l => l !== null);

  return lines.join('\n');
}

// ── Build plan buttons for a product ─────────────────────────────────────────
function buildPlanButtons(product) {
  const sym = config.app.currencySymbol;
  const plans = parsePlans(product);
  const isAvailable = product.StockStatus !== config.stockStatus.OUT_OF_STOCK;

  // Group plans into rows of 2
  const buttons = [];
  const row = [];

  for (const plan of plans) {
    const label = isAvailable
      ? `💳 Buy ${plan.name} — ${sym}${plan.price}`
      : `❌ ${plan.name} — Unavailable`;

    const callbackData = isAvailable
      ? `buy_${product.ProductID}_${plan.name}_${plan.price}`
      : `unavailable_${product.ProductID}`;

    row.push({ text: label, callback_data: callbackData });

    if (row.length === 2) {
      buttons.push([...row]);
      row.length = 0;
    }
  }
  if (row.length > 0) buttons.push([...row]);

  return buttons;
}

// ── Parse plans from product row ─────────────────────────────────────────────
// Products sheet stores PlanName as comma-separated and Price as comma-separated
// e.g. PlanName="1 Month,3 Month,6 Month"  Price="299,699,1199"
function parsePlans(product) {
  const names = (product.PlanName || '').split(',').map(s => s.trim()).filter(Boolean);
  const prices = (product.Price || '').split(',').map(s => s.trim()).filter(Boolean);

  if (names.length === 0) {
    // Single plan fallback
    return [{ name: product.ButtonLabel || 'Buy Now', price: product.Price || '0' }];
  }

  return names.map((name, i) => ({
    name,
    price: prices[i] || prices[0] || '0',
  }));
}

// ── Order status messages ────────────────────────────────────────────────────
function getStatusMessage(status, productName) {
  const messages = {
    Pending:   `⏳ <b>Order Pending</b>\n\nYour order for <b>${productName}</b> is under admin review. You'll be notified soon.`,
    Approved:  `✅ <b>Order Approved</b>\n\nGreat news! Your order for <b>${productName}</b> has been approved. Delivery is being arranged.`,
    Rejected:  `❌ <b>Order Rejected</b>\n\nSorry, your order for <b>${productName}</b> is currently unavailable. Please contact @${config.telegram.supportUsername} for assistance.`,
    Waiting:   `⏳ <b>Stock Unavailable</b>\n\nYour order for <b>${productName}</b> is placed but stock is temporarily unavailable. We'll notify you when ready.`,
    Delivered: `🎉 <b>Order Delivered!</b>\n\nYour order for <b>${productName}</b> has been delivered successfully! Thank you for your purchase.`,
    Cancelled: `🚫 <b>Order Cancelled</b>\n\nYour order for <b>${productName}</b> has been cancelled. If you paid, please contact @${config.telegram.supportUsername} for a refund.`,
  };
  return messages[status] || `📦 Order status updated to: <b>${status}</b>`;
}

// ── Format order for admin view ──────────────────────────────────────────────
function formatOrderForAdmin(order) {
  const sym = config.app.currencySymbol;
  return [
    `🛒 <b>New Order Request</b>`,
    ``,
    `👤 <b>User:</b> ${order.Username ? '@' + order.Username : order.FullName || 'Unknown'}`,
    `🆔 <b>User ID:</b> <code>${order.TelegramUserID}</code>`,
    `📦 <b>Product:</b> ${order.ProductName}`,
    `🎯 <b>Plan:</b> ${order.PlanName}`,
    `💰 <b>Price:</b> ${sym}${order.Price}`,
    `🆔 <b>Order ID:</b> <code>${order.OrderID}</code>`,
    `💳 <b>Transaction:</b> <code>${order.TransactionID || 'N/A'}</code>`,
    `📅 <b>Date:</b> ${order.CreatedAt}`,
  ].join('\n');
}

// ── Admin action buttons ─────────────────────────────────────────────────────
function buildAdminActionButtons(orderId) {
  return [
    [
      { text: '✅ Approve', callback_data: `admin_approve_${orderId}` },
      { text: '❌ Reject', callback_data: `admin_reject_${orderId}` },
    ],
    [
      { text: '⏳ Waiting', callback_data: `admin_waiting_${orderId}` },
      { text: '📦 Delivered', callback_data: `admin_delivered_${orderId}` },
    ],
  ];
}

// ── Escape HTML ──────────────────────────────────────────────────────────────
function escapeHtml(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// ── Get today's date string ──────────────────────────────────────────────────
function today() {
  return dayjs().format('YYYY-MM-DD');
}

function nowISO() {
  return dayjs().format('YYYY-MM-DD HH:mm:ss');
}

// ── Apply coupon discount ────────────────────────────────────────────────────
function applyCoupon(price, coupon) {
  if (!coupon) return price;
  const p = parseFloat(price);
  if (coupon.DiscountType === 'Percent') {
    const disc = Math.min(parseFloat(coupon.DiscountValue), 100);
    return Math.max(0, p - (p * disc / 100)).toFixed(0);
  } else if (coupon.DiscountType === 'Flat') {
    return Math.max(0, p - parseFloat(coupon.DiscountValue)).toFixed(0);
  }
  return price;
}

module.exports = {
  formatProductMessage,
  buildPlanButtons,
  parsePlans,
  getStatusMessage,
  formatOrderForAdmin,
  buildAdminActionButtons,
  escapeHtml,
  today,
  nowISO,
  applyCoupon,
};
