#!/usr/bin/env node
/**
 * Setup verification script
 * Run: node src/utils/setup.js
 * Checks all required environment variables and connections.
 */

require('dotenv').config();
const { google } = require('googleapis');
const https = require('https');

const checks = [];
let passed = 0;
let failed = 0;

function check(name, condition, hint = '') {
  const ok = Boolean(condition);
  const icon = ok ? '✅' : '❌';
  console.log(`${icon} ${name}${!ok && hint ? `\n   → ${hint}` : ''}`);
  if (ok) passed++;
  else failed++;
}

async function checkGoogleSheets() {
  const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  const key = (process.env.GOOGLE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
  const sheetId = process.env.GOOGLE_SHEET_ID;

  if (!email || !key || !sheetId) {
    check('Google Sheets connection', false, 'Missing GOOGLE_* env vars');
    return;
  }

  try {
    const auth = new google.auth.JWT(email, null, key, ['https://www.googleapis.com/auth/spreadsheets']);
    const sheets = google.sheets({ version: 'v4', auth });
    await sheets.spreadsheets.get({ spreadsheetId: sheetId });
    check('Google Sheets connection', true);

    // Check for required tabs
    const res = await sheets.spreadsheets.get({ spreadsheetId: sheetId });
    const tabNames = res.data.sheets.map(s => s.properties.title);
    const required = ['Products', 'Orders', 'Admins', 'Coupons', 'Settings', 'Analytics'];
    for (const tab of required) {
      check(`  Sheet tab: ${tab}`, tabNames.includes(tab), `Create a tab named "${tab}" in your Google Sheet`);
    }
  } catch (e) {
    check('Google Sheets connection', false, e.message);
  }
}

async function checkTelegramBot() {
  const token = process.env.BOT_TOKEN;
  if (!token) {
    check('Telegram bot token', false, 'Set BOT_TOKEN in .env');
    return;
  }

  return new Promise(resolve => {
    https.get(`https://api.telegram.org/bot${token}/getMe`, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          check('Telegram bot token', json.ok, json.description || 'Invalid token');
          if (json.ok) {
            console.log(`   Bot: @${json.result.username}`);
          }
        } catch {
          check('Telegram bot token', false, 'Could not parse response');
        }
        resolve();
      });
    }).on('error', e => {
      check('Telegram bot token', false, e.message);
      resolve();
    });
  });
}

async function main() {
  console.log('\n🔍 Telegram Ecommerce Bot — Setup Check\n');
  console.log('─'.repeat(45));

  // Env vars
  console.log('\n📋 Environment Variables:\n');
  check('BOT_TOKEN', process.env.BOT_TOKEN, 'Get from @BotFather');
  check('ADMIN_IDS', process.env.ADMIN_IDS, 'Your Telegram numeric ID');
  check('GOOGLE_SHEET_ID', process.env.GOOGLE_SHEET_ID, 'From your Google Sheet URL');
  check('GOOGLE_SERVICE_ACCOUNT_EMAIL', process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL, 'From service account JSON');
  check('GOOGLE_PRIVATE_KEY', process.env.GOOGLE_PRIVATE_KEY, 'From service account JSON');
  check('WEBHOOK_DOMAIN', process.env.WEBHOOK_DOMAIN || process.env.NODE_ENV !== 'production', 'Required in production');

  // External connections
  console.log('\n🌐 External Connections:\n');
  await checkTelegramBot();
  await checkGoogleSheets();

  // Summary
  console.log('\n' + '─'.repeat(45));
  console.log(`\n📊 Results: ${passed} passed, ${failed} failed`);

  if (failed === 0) {
    console.log('\n🎉 Everything looks good! Run `npm start` to launch your bot.\n');
  } else {
    console.log('\n⚠️  Fix the issues above before deploying.\n');
    console.log('📖 See README.md for detailed setup instructions.\n');
  }
}

main().catch(console.error);
