const { Markup } = require('telegraf');
const sheets = require('../database/sheets');
const helpers = require('../utils/helpers');
const config = require('../config/config');

// ── /admin — Admin dashboard ─────────────────────────────────────────────────
async function adminCommand(ctx) {
  const pendingOrders = await sheets.getPendingOrders();

  const text = [
    `🔧 <b>Admin Dashboard</b>`,
    ``,
    `👤 Logged in as: <b>${ctx.fullName}</b>`,
    `📋 Pending Orders: <b>${pendingOrders.length}</b>`,
    ``,
    `Choose an action:`,
  ].join('\n');

  await ctx.reply(text, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [
        { text: '📋 Pending Orders', callback_data: 'admin_pending' },
        { text: '📊 Statistics', callback_data: 'admin_stats' },
      ],
      [
        { text: '👥 Users', callback_data: 'admin_users' },
        { text: '📢 Broadcast', callback_data: 'admin_broadcast_menu' },
      ],
      [
        { text: '🔄 Refresh Cache', callback_data: 'admin_refresh_cache' },
      ],
    ]),
  });
}

// ── /orders — List pending orders ────────────────────────────────────────────
async function ordersCommand(ctx) {
  const orders = await sheets.getPendingOrders();

  if (orders.length === 0) {
    return ctx.reply('✅ No pending orders right now.', { parse_mode: 'HTML' });
  }

  await ctx.reply(`📋 <b>${orders.length} Pending Order(s):</b>`, { parse_mode: 'HTML' });

  for (const order of orders.slice(0, 10)) { // Show max 10
    const text = helpers.formatOrderForAdmin(order);
    const buttons = helpers.buildAdminActionButtons(order.OrderID);
    await ctx.reply(text, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard(buttons),
    });
    await new Promise(r => setTimeout(r, 200)); // Small delay between messages
  }

  if (orders.length > 10) {
    await ctx.reply(`... and ${orders.length - 10} more orders. Check Google Sheets for full list.`);
  }
}

// ── /stats — Show statistics ─────────────────────────────────────────────────
async function statsCommand(ctx) {
  const orders = await sheets.readSheet(config.sheets.orders, false);
  const total = orders.length;
  const paid = orders.filter(o => o.PaymentStatus === 'Paid').length;
  const delivered = orders.filter(o => o.OrderStatus === 'Delivered').length;
  const pending = orders.filter(o => o.OrderStatus === 'Pending').length;
  const revenue = orders
    .filter(o => o.PaymentStatus === 'Paid')
    .reduce((sum, o) => sum + (parseFloat(o.Price) || 0), 0);

  const sym = config.app.currencySymbol;
  const text = [
    `📊 <b>Store Statistics</b>`,
    ``,
    `📦 Total Orders: <b>${total}</b>`,
    `✅ Paid Orders: <b>${paid}</b>`,
    `📬 Delivered: <b>${delivered}</b>`,
    `⏳ Pending: <b>${pending}</b>`,
    `💰 Total Revenue: <b>${sym}${revenue.toFixed(0)}</b>`,
  ].join('\n');

  await ctx.reply(text, { parse_mode: 'HTML' });
}

// ── /broadcast — Broadcast a message to all users ─────────────────────────────
async function broadcastCommand(ctx) {
  if (!ctx.session?.awaitingBroadcast) {
    ctx.session = { awaitingBroadcast: true };
    return ctx.reply(
      '📢 <b>Broadcast Message</b>\n\nSend the message you want to broadcast to all users.\n\nType /cancel to abort.',
      { parse_mode: 'HTML' }
    );
  }
}

// ── Handle admin action callbacks ────────────────────────────────────────────
async function handleAdminAction(ctx, bot) {
  const data = ctx.callbackQuery.data;

  if (data === 'admin_pending') {
    await ctx.answerCbQuery('Loading pending orders...');
    return ordersCommand(ctx);
  }

  if (data === 'admin_stats') {
    await ctx.answerCbQuery();
    return statsCommand(ctx);
  }

  if (data === 'admin_refresh_cache') {
    const { clearCache } = require('../database/sheets');
    clearCache();
    await ctx.answerCbQuery('✅ Cache cleared!');
    return ctx.reply('✅ Google Sheets cache has been refreshed.');
  }

  // Order status updates
  const orderMatch = data.match(/^admin_(approve|reject|waiting|delivered)_(.+)$/);
  if (orderMatch) {
    const action = orderMatch[1];
    const orderId = orderMatch[2];
    await handleOrderAction(ctx, bot, orderId, action);
    return;
  }
}

async function handleOrderAction(ctx, bot, orderId, action) {
  const statusMap = {
    approve: config.orderStatus.APPROVED,
    reject: config.orderStatus.REJECTED,
    waiting: config.orderStatus.WAITING,
    delivered: config.orderStatus.DELIVERED,
  };

  const newStatus = statusMap[action];
  if (!newStatus) return ctx.answerCbQuery('Unknown action');

  // Get order
  const order = await sheets.getOrderById(orderId);
  if (!order) {
    await ctx.answerCbQuery('Order not found');
    return ctx.reply(`❌ Order ${orderId} not found.`);
  }

  // Update sheet
  await sheets.updateOrder(orderId, {
    OrderStatus: newStatus,
    UpdatedAt: helpers.nowISO(),
    AdminNotes: `Updated to ${newStatus} by admin ${ctx.from.id}`,
  });

  await ctx.answerCbQuery(`✅ Order ${newStatus}`);

  // Edit the admin message to show new status
  try {
    await ctx.editMessageText(
      ctx.callbackQuery.message.text + `\n\n✅ <b>Status updated to: ${newStatus}</b>`,
      { parse_mode: 'HTML' }
    );
  } catch {}

  // If delivered, trigger delivery
  if (action === 'delivered') {
    const product = await sheets.getProductById(order.ProductID);
    if (product) {
      const delivery = require('../services/delivery');
      const result = await delivery.deliverProduct(bot, parseInt(order.TelegramUserID), product, order);
      if (!result.success) {
        await ctx.reply(`⚠️ Delivery failed for order ${orderId}: ${result.message}`);
        return;
      }
      await sheets.updateOrder(orderId, {
        DeliveryStatus: 'Delivered',
        UpdatedAt: helpers.nowISO(),
      });
    }
  }

  // Notify the customer
  const statusMsg = helpers.getStatusMessage(newStatus, order.ProductName);
  try {
    await bot.telegram.sendMessage(parseInt(order.TelegramUserID), statusMsg, { parse_mode: 'HTML' });
    await ctx.reply(`✅ Customer @${order.Username || order.TelegramUserID} has been notified.`);
  } catch (e) {
    await ctx.reply(`⚠️ Could not notify customer: ${e.message}`);
  }
}

module.exports = { adminCommand, ordersCommand, statsCommand, broadcastCommand, handleAdminAction };
