const { Markup } = require('telegraf');
const sheets = require('../database/sheets');
const config = require('../config/config');

async function startCommand(ctx) {
  const name = ctx.from.first_name || 'there';

  // Try to get welcome message from settings
  let welcomeText;
  try {
    const msg = await sheets.getSetting('welcome_message');
    welcomeText = msg ? msg.replace('{name}', name) : null;
  } catch {}

  if (!welcomeText) {
    welcomeText = [
      `👋 <b>Welcome, ${name}!</b>`,
      ``,
      `🛒 <b>Your Digital Products Store</b>`,
      ``,
      `Find premium digital products, bundles, subscriptions, and more — all delivered instantly or with express admin processing.`,
      ``,
      `👇 Choose an option below to get started:`,
    ].join('\n');
  }

  const keyboard = Markup.inlineKeyboard([
    [
      { text: '🛍 Browse Products', callback_data: 'menu_browse' },
      { text: '🔥 Best Sellers', callback_data: 'menu_featured' },
    ],
    [
      { text: '📦 My Orders', callback_data: 'menu_orders' },
      { text: '🎁 Offers & Coupons', callback_data: 'menu_offers' },
    ],
    [
      { text: '💬 Support', callback_data: 'menu_support' },
    ],
  ]);

  // Try to get banner image
  let bannerFileId;
  try {
    bannerFileId = await sheets.getSetting('banner_file_id');
  } catch {}

  if (bannerFileId) {
    await ctx.replyWithPhoto(bannerFileId, {
      caption: welcomeText,
      parse_mode: 'HTML',
      ...keyboard,
    });
  } else {
    await ctx.reply(welcomeText, { parse_mode: 'HTML', ...keyboard });
  }
}

module.exports = { startCommand };
