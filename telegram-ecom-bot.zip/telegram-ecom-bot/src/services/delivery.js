const config = require('../config/config');

/**
 * Deliver a product to a user based on the product's DeliveryMethod.
 * Returns { success, message } and sends to the bot context.
 */
async function deliverProduct(bot, userId, product, order) {
  const { deliveryMethods } = config;
  const method = product.DeliveryMethod;

  try {
    switch (method) {
      case deliveryMethods.TELEGRAM_FILE:
        return await deliverTelegramFile(bot, userId, product, order);

      case deliveryMethods.DRIVE_LINK:
        return await deliverDriveLink(bot, userId, product, order);

      case deliveryMethods.CHANNEL_INVITE:
        return await deliverChannelInvite(bot, userId, product, order);

      case deliveryMethods.TEXT_LICENSE:
        return await deliverTextLicense(bot, userId, product, order);

      case deliveryMethods.MANUAL:
        // Will be handled by admin
        return { success: true, message: 'Manual delivery — admin notified.' };

      default:
        throw new Error(`Unknown delivery method: ${method}`);
    }
  } catch (err) {
    console.error(`[Delivery] Error for order ${order.OrderID}:`, err.message);
    return { success: false, message: err.message };
  }
}

// ── Deliver a file stored in a Telegram channel ──────────────────────────────
async function deliverTelegramFile(bot, userId, product, order) {
  const fileId = product.ImageFileID; // Reuse the file_id field for delivery file

  if (!fileId) throw new Error('No file_id configured for this product.');

  // Try to forward the file from the media channel
  if (config.telegram.mediaChannelId) {
    try {
      await bot.telegram.copyMessage(userId, config.telegram.mediaChannelId, parseInt(product.MediaMessageID || fileId));
      await sendDeliveryConfirmation(bot, userId, product, order);
      return { success: true };
    } catch (e) {
      // Fall through to direct file send
    }
  }

  // Send as document/photo using stored file_id
  const caption = buildDeliveryCaption(product, order);
  try {
    await bot.telegram.sendDocument(userId, fileId, { caption, parse_mode: 'HTML' });
  } catch {
    // If it's a photo
    await bot.telegram.sendPhoto(userId, fileId, { caption, parse_mode: 'HTML' });
  }

  await sendDeliveryConfirmation(bot, userId, product, order);
  return { success: true };
}

// ── Deliver a Google Drive or external link ───────────────────────────────────
async function deliverDriveLink(bot, userId, product, order) {
  const link = product.DeliveryLink;
  if (!link) throw new Error('No delivery link configured for this product.');

  const caption = buildDeliveryCaption(product, order);
  const message = `${caption}\n\n📥 <b>Download Link:</b>\n${link}\n\n⚠️ <i>Keep this link private. Do not share it.</i>`;

  await bot.telegram.sendMessage(userId, message, { parse_mode: 'HTML', disable_web_page_preview: false });
  return { success: true };
}

// ── Deliver a private Telegram channel invite ─────────────────────────────────
async function deliverChannelInvite(bot, userId, product, order) {
  const inviteLink = product.DeliveryLink;
  if (!inviteLink) throw new Error('No invite link configured for this product.');

  const caption = buildDeliveryCaption(product, order);
  const message = `${caption}\n\n🔗 <b>Join Channel:</b>\n${inviteLink}\n\n⚠️ <i>This invite link is for your use only.</i>`;

  await bot.telegram.sendMessage(userId, message, { parse_mode: 'HTML' });
  return { success: true };
}

// ── Deliver a text license/key ────────────────────────────────────────────────
async function deliverTextLicense(bot, userId, product, order) {
  const licenseText = product.DeliveryLink; // Overloading field for license text
  if (!licenseText) throw new Error('No license text configured for this product.');

  const caption = buildDeliveryCaption(product, order);
  const message = `${caption}\n\n🔑 <b>License / Credentials:</b>\n<code>${licenseText}</code>\n\n⚠️ <i>Keep this private. Do not share.</i>`;

  await bot.telegram.sendMessage(userId, message, { parse_mode: 'HTML' });
  return { success: true };
}

// ── Helpers ──────────────────────────────────────────────────────────────────
function buildDeliveryCaption(product, order) {
  const sym = config.app.currencySymbol;
  return [
    `✅ <b>Order Delivered!</b>`,
    ``,
    `📦 <b>Product:</b> ${product.ProductName}`,
    `🎯 <b>Plan:</b> ${order.PlanName}`,
    `💰 <b>Amount Paid:</b> ${sym}${order.Price}`,
    `🆔 <b>Order ID:</b> <code>${order.OrderID}</code>`,
    ``,
    `Thank you for your purchase! 🎉`,
  ].join('\n');
}

async function sendDeliveryConfirmation(bot, userId, product, order) {
  await bot.telegram.sendMessage(
    userId,
    `✅ <b>Delivery Complete!</b>\n\nYour <b>${product.ProductName}</b> has been delivered above.\n\n📞 Need help? Contact @${config.telegram.supportUsername}`,
    { parse_mode: 'HTML' }
  );
}

module.exports = { deliverProduct };
