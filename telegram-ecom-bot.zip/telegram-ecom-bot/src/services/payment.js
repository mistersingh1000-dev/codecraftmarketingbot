const axios = require('axios');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const config = require('../config/config');

// ── Generate a unique Order ID ────────────────────────────────────────────────
function generateOrderId() {
  return 'ORD-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
}

// ── Build a SuperProfile payment link ────────────────────────────────────────
// SuperProfile uses a link format:
// https://superprofile.bio/<store_id>/checkout?product=...&amount=...&ref=...
// If you have API access, it can also be done via their API.
async function generatePaymentLink({ orderId, productName, planName, price, username }) {
  const { currencySymbol } = config.app;

  // Method 1: SuperProfile API (if available)
  if (config.payment.superprofileApiKey && config.payment.superprofileStoreId) {
    try {
      const res = await axios.post(
        'https://api.superprofile.bio/v1/orders/create',
        {
          store_id: config.payment.superprofileStoreId,
          order_id: orderId,
          product_name: productName,
          plan: planName,
          amount: price,
          currency: 'INR',
          buyer_name: username || 'Telegram User',
          success_url: `${config.payment.successUrl}?order_id=${orderId}`,
          failure_url: `${config.payment.failedUrl}?order_id=${orderId}`,
        },
        {
          headers: {
            Authorization: `Bearer ${config.payment.superprofileApiKey}`,
            'Content-Type': 'application/json',
          },
          timeout: 5000,
        }
      );
      if (res.data && res.data.payment_url) {
        return res.data.payment_url;
      }
    } catch (err) {
      console.error('[Payment] SuperProfile API error, falling back to manual link:', err.message);
    }
  }

  // Method 2: Fallback — UPI deep link / manual payment page
  // Replace with your actual UPI ID or payment page URL
  const upiId = await getSettingFallback('upi_id', 'yourupi@paytm');
  const note = encodeURIComponent(`${orderId} - ${productName} ${planName}`);
  const upiLink = `upi://pay?pa=${upiId}&pn=${encodeURIComponent('Digital Store')}&am=${price}&cu=INR&tn=${note}`;

  // Return the bot's own payment confirmation page
  return `${config.server.webhookDomain}/pay?order_id=${orderId}&amount=${price}&product=${encodeURIComponent(productName)}&plan=${encodeURIComponent(planName)}&upi=${encodeURIComponent(upiLink)}`;
}

// Helper to avoid circular dep with sheets
async function getSettingFallback(name, fallback) {
  try {
    const sheets = require('../database/sheets');
    const val = await sheets.getSetting(name);
    return val || fallback;
  } catch {
    return fallback;
  }
}

// ── Verify SuperProfile webhook signature ────────────────────────────────────
function verifyWebhookSignature(rawBody, signature) {
  if (!config.payment.webhookSecret) return true; // skip if not configured
  const expected = crypto
    .createHmac('sha256', config.payment.webhookSecret)
    .update(rawBody)
    .digest('hex');
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature || ''));
}

// ── Parse incoming webhook payload ───────────────────────────────────────────
function parseWebhookPayload(body) {
  // SuperProfile webhook format (adapt to actual docs if different)
  return {
    orderId: body.order_id || body.orderId || body.reference_id,
    transactionId: body.transaction_id || body.payment_id,
    status: body.status, // 'paid' | 'failed'
    amount: body.amount,
    payerName: body.payer_name,
    payerContact: body.payer_contact,
  };
}

module.exports = {
  generateOrderId,
  generatePaymentLink,
  verifyWebhookSignature,
  parseWebhookPayload,
};
