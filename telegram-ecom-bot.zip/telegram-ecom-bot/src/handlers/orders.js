const { Markup } = require('telegraf');
const sheets = require('../database/sheets');
const payment = require('../services/payment');
const delivery = require('../services/delivery');
const helpers = require('../utils/helpers');
const config = require('../config/config');

// ── Start buy flow: user clicked a plan button ────────────────────────────────
// callback_data format: buy_{productId}_{planName}_{price}
async function handleBuyClick(ctx, bot) {
  await ctx.answerCbQuery('Processing...').catch(() => {});

  const data = ctx.callbackQuery.data;
  const match = data.match(/^buy_([^_]+)_(.+)_(\d+(?:\.\d+)?)$/);
  if (!match) return ctx.reply('Invalid action. Please try again.');

  const [, productId, planName, price] = match;
  const product = await sheets.getProductById(productId);

  if (!product) return ctx.reply('❌ Product not found. Please try again.');

  if (product.StockStatus === config.stockStatus.OUT_OF_STOCK) {
    return ctx.reply('❌ This product is currently out of stock.');
  }

  // Check for coupon in user session (if you want to support it)
  let finalPrice = price;
  let couponUsed = null;
  if (ctx.session?.coupon) {
    const couponData = await sheets.getCoupon(ctx.session.coupon);
    if (couponData && parseFloat(couponData.MinimumOrder || 0) <= parseFloat(price)) {
      finalPrice = helpers.applyCoupon(price, couponData);
      couponUsed = couponData.CouponCode;
    }
  }

  // Create order record
  const orderId = payment.generateOrderId();
  const orderData = {
    OrderID: orderId,
    TelegramUserID: ctx.userId,
    Username: ctx.username,
    FullName: ctx.fullName,
    ProductID: productId,
    ProductName: product.ProductName,
    PlanName: planName,
    Price: finalPrice,
    PaymentStatus: config.paymentStatus.PENDING,
    OrderStatus: config.orderStatus.PENDING,
    TransactionID: '',
    PaymentLink: '',
    DeliveryStatus: 'Pending',
    AdminNotes: couponUsed ? `Coupon: ${couponUsed}` : '',
    CreatedAt: helpers.nowISO(),
    UpdatedAt: helpers.nowISO(),
  };

  await sheets.createOrder(orderData);

  // Generate payment link
  let paymentLink;
  try {
    paymentLink = await payment.generatePaymentLink({
      orderId,
      productName: product.ProductName,
      planName,
      price: finalPrice,
      username: ctx.username,
    });
  } catch (e) {
    console.error('[Orders] Payment link error:', e.message);
    return ctx.reply('⚠️ Could not generate payment link. Please contact support.');
  }

  // Update order with payment link
  await sheets.updateOrder(orderId, { PaymentLink: paymentLink, UpdatedAt: helpers.nowISO() });

  const sym = config.app.currencySymbol;
  const couponLine = couponUsed ? `\n🎫 Coupon Applied: <b>${couponUsed}</b>` : '';
  const originalLine = couponUsed ? `\n~~Original Price: ${sym}${price}~~` : '';

  const text = [
    `💳 <b>Payment Details</b>`,
    ``,
    `📦 <b>Product:</b> ${product.ProductName}`,
    `🎯 <b>Plan:</b> ${planName}`,
    `💰 <b>Amount:</b> ${sym}${finalPrice}${originalLine}${couponLine}`,
    `🆔 <b>Order ID:</b> <code>${orderId}</code>`,
    ``,
    `Click the button below to complete your payment:`,
    ``,
    `⚠️ <i>After payment, your order will be processed automatically.</i>`,
  ].join('\n');

  await ctx.reply(text, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [{ text: `💳 Pay ${sym}${finalPrice}`, url: paymentLink }],
      [{ text: '✅ I Have Paid', callback_data: `confirm_payment_${orderId}` }],
      [{ text: '❌ Cancel', callback_data: `cancel_order_${orderId}` }],
    ]),
  });
}

// ── User confirms payment (manual confirmation flow) ──────────────────────────
async function handlePaymentConfirm(ctx, bot) {
  const data = ctx.callbackQuery.data;
  const orderId = data.replace('confirm_payment_', '');

  await ctx.answerCbQuery('Verifying payment...').catch(() => {});

  const order = await sheets.getOrderById(orderId);
  if (!order) {
    return ctx.reply('❌ Order not found. Please contact support.');
  }

  if (order.TelegramUserID !== String(ctx.userId)) {
    return ctx.reply('⛔ This order does not belong to you.');
  }

  // Mark as paid (in a real implementation, verify via webhook)
  await sheets.updateOrder(orderId, {
    PaymentStatus: config.paymentStatus.PAID,
    UpdatedAt: helpers.nowISO(),
  });

  const product = await sheets.getProductById(order.ProductID);
  if (!product) return ctx.reply('⚠️ Product data missing. Contact support.');

  // ── INSTANT delivery ──────────────────────────────────────────────────────
  if (product.ProductType === config.productTypes.INSTANT) {
    await ctx.reply(
      `✅ <b>Payment Confirmed!</b>\n\nProcessing your delivery...`,
      { parse_mode: 'HTML' }
    );

    const result = await delivery.deliverProduct(bot, ctx.userId, product, order);

    if (result.success) {
      await sheets.updateOrder(orderId, {
        OrderStatus: config.orderStatus.DELIVERED,
        DeliveryStatus: 'Delivered',
        UpdatedAt: helpers.nowISO(),
      });

      // Update analytics
      try {
        const { today } = helpers;
        await sheets.updateAnalytics(today(), {
          TotalOrders: 1,
          TotalRevenue: parseFloat(order.Price),
          DeliveredOrders: 1,
        });
      } catch {}

    } else {
      await ctx.reply(`⚠️ Delivery issue: ${result.message}\n\nPlease contact @${config.telegram.supportUsername}`);
    }
    return;
  }

  // ── MANUAL approval flow ──────────────────────────────────────────────────
  await sheets.updateOrder(orderId, {
    OrderStatus: config.orderStatus.PENDING,
    UpdatedAt: helpers.nowISO(),
  });

  await ctx.reply(
    helpers.getStatusMessage(config.orderStatus.PENDING, product.ProductName),
    { parse_mode: 'HTML' }
  );

  // Notify all admins
  const orderText = helpers.formatOrderForAdmin({ ...order, PaymentStatus: config.paymentStatus.PAID });
  const adminButtons = helpers.buildAdminActionButtons(orderId);

  for (const adminId of config.telegram.adminIds) {
    try {
      await bot.telegram.sendMessage(adminId, orderText, {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard(adminButtons),
      });
    } catch (e) {
      console.error(`[Orders] Could not notify admin ${adminId}:`, e.message);
    }
  }
}

// ── Cancel order ─────────────────────────────────────────────────────────────
async function handleCancelOrder(ctx) {
  const orderId = ctx.callbackQuery.data.replace('cancel_order_', '');
  await ctx.answerCbQuery('Order cancelled').catch(() => {});

  const order = await sheets.getOrderById(orderId);
  if (order && order.TelegramUserID === String(ctx.userId)) {
    await sheets.updateOrder(orderId, {
      OrderStatus: config.orderStatus.CANCELLED,
      UpdatedAt: helpers.nowISO(),
    });
  }

  await ctx.reply('🚫 Order cancelled. Feel free to browse our products anytime!', {
    ...Markup.inlineKeyboard([[{ text: '🛍 Browse Products', callback_data: 'menu_browse' }]]),
  });
}

// ── Show user's order history ─────────────────────────────────────────────────
async function showMyOrders(ctx) {
  await ctx.answerCbQuery('Loading orders...').catch(() => {});

  const orders = await sheets.getOrdersByUser(ctx.userId);
  const sym = config.app.currencySymbol;

  if (orders.length === 0) {
    return ctx.reply(
      `📦 <b>My Orders</b>\n\nYou haven't placed any orders yet.\n\nStart shopping! 👇`,
      {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[{ text: '🛍 Browse Products', callback_data: 'menu_browse' }]]),
      }
    );
  }

  // Show last 5 orders
  const recent = orders.slice(-5).reverse();
  const statusEmoji = {
    Pending: '⏳', Approved: '✅', Rejected: '❌',
    Waiting: '⏸', Delivered: '📬', Cancelled: '🚫',
  };

  let text = `📦 <b>My Orders</b>\n\nYour recent orders:\n\n`;
  for (const o of recent) {
    const emoji = statusEmoji[o.OrderStatus] || '📦';
    text += `${emoji} <b>${o.ProductName}</b> — ${o.PlanName}\n`;
    text += `   ${sym}${o.Price} | <code>${o.OrderID}</code> | ${o.OrderStatus}\n\n`;
  }

  if (orders.length > 5) {
    text += `<i>Showing 5 of ${orders.length} orders.</i>`;
  }

  await ctx.reply(text, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([[{ text: '🔙 Main Menu', callback_data: 'menu_main' }]]),
  });
}

// ── Handle coupon application ─────────────────────────────────────────────────
async function handleCouponInput(ctx, couponCode) {
  const coupon = await sheets.getCoupon(couponCode.toUpperCase());

  if (!coupon) {
    return ctx.reply('❌ Invalid or expired coupon code.');
  }

  if (!ctx.session) ctx.session = {};
  ctx.session.coupon = couponCode.toUpperCase();

  const sym = config.app.currencySymbol;
  const disc = coupon.DiscountType === 'Percent'
    ? `${coupon.DiscountValue}% OFF`
    : `${sym}${coupon.DiscountValue} OFF`;

  await ctx.reply(
    `✅ Coupon <b>${couponCode.toUpperCase()}</b> applied!\n${disc} on your next purchase.`,
    { parse_mode: 'HTML' }
  );
}

module.exports = {
  handleBuyClick,
  handlePaymentConfirm,
  handleCancelOrder,
  showMyOrders,
  handleCouponInput,
};
