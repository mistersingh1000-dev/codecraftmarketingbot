const { Markup } = require('telegraf');
const sheets = require('../database/sheets');
const helpers = require('../utils/helpers');
const config = require('../config/config');

// ── Show categories ──────────────────────────────────────────────────────────
async function showCategories(ctx) {
  await ctx.answerCbQuery('Loading products...').catch(() => {});

  const categorized = await sheets.getProductsByCategory();
  const categories = Object.keys(categorized);

  if (categories.length === 0) {
    return ctx.reply('🛍 No products available right now. Check back soon!');
  }

  const buttons = categories.map(cat => [
    { text: `📂 ${cat} (${categorized[cat].length})`, callback_data: `cat_${encodeURIComponent(cat)}` }
  ]);
  buttons.push([{ text: '🔙 Main Menu', callback_data: 'menu_main' }]);

  await ctx.reply('🛍 <b>Browse Products</b>\n\nSelect a category:', {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard(buttons),
  });
}

// ── Show products in a category ──────────────────────────────────────────────
async function showCategoryProducts(ctx, category) {
  await ctx.answerCbQuery('Loading...').catch(() => {});

  const categorized = await sheets.getProductsByCategory();
  const products = categorized[category] || [];

  if (products.length === 0) {
    return ctx.reply('No products in this category right now.', {
      ...Markup.inlineKeyboard([[{ text: '🔙 Categories', callback_data: 'menu_browse' }]]),
    });
  }

  const buttons = products.map(p => {
    const badge = p.StockStatus === config.stockStatus.OUT_OF_STOCK ? '❌' :
                  p.StockStatus === config.stockStatus.LIMITED ? '🔥' : '✅';
    return [{ text: `${badge} ${p.ProductName}`, callback_data: `product_${p.ProductID}` }];
  });
  buttons.push([{ text: '🔙 Categories', callback_data: 'menu_browse' }]);

  await ctx.reply(`📂 <b>${category}</b>\n\nChoose a product:`, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard(buttons),
  });
}

// ── Show single product detail ───────────────────────────────────────────────
async function showProduct(ctx, productId) {
  await ctx.answerCbQuery('Loading product...').catch(() => {});

  const product = await sheets.getProductById(productId);
  if (!product) {
    return ctx.reply('Product not found.', {
      ...Markup.inlineKeyboard([[{ text: '🔙 Browse', callback_data: 'menu_browse' }]]),
    });
  }

  const sym = config.app.currencySymbol;
  const planButtons = helpers.buildPlanButtons(product);

  // Add back button
  planButtons.push([{ text: '🔙 Back', callback_data: `cat_${encodeURIComponent(product.Category)}` }]);

  const mainText = helpers.formatProductMessage(product);
  const fullDesc = product.FullDescription ? `\n\n📖 ${product.FullDescription}` : '';
  const messageText = mainText + fullDesc;

  // Try to send with product image
  if (product.ImageFileID && product.ImageFileID.trim()) {
    try {
      await ctx.replyWithPhoto(product.ImageFileID.trim(), {
        caption: messageText,
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard(planButtons),
      });
      return;
    } catch (e) {
      console.error('[Shop] Could not send product image:', e.message);
    }
  }

  // Fallback: text only
  await ctx.reply(messageText, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard(planButtons),
  });
}

// ── Show featured / best sellers ─────────────────────────────────────────────
async function showFeatured(ctx) {
  await ctx.answerCbQuery('Loading best sellers...').catch(() => {});

  const products = await sheets.getFeaturedProducts();

  if (products.length === 0) {
    return ctx.reply('🔥 No featured products at the moment.', {
      ...Markup.inlineKeyboard([[{ text: '🔙 Main Menu', callback_data: 'menu_main' }]]),
    });
  }

  const buttons = products.map(p => [
    { text: `🔥 ${p.ProductName}`, callback_data: `product_${p.ProductID}` }
  ]);
  buttons.push([{ text: '🔙 Main Menu', callback_data: 'menu_main' }]);

  await ctx.reply('🔥 <b>Best Sellers</b>\n\nOur most popular products:', {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard(buttons),
  });
}

// ── Show offers / coupons info ────────────────────────────────────────────────
async function showOffers(ctx) {
  await ctx.answerCbQuery().catch(() => {});

  const couponsData = await sheets.readSheet(config.sheets.coupons).catch(() => []);
  const activeCoupons = couponsData.filter(c => c.Status === 'Active');

  let text = '🎁 <b>Offers & Coupons</b>\n\n';

  if (activeCoupons.length > 0) {
    text += 'Use these coupon codes at checkout:\n\n';
    for (const c of activeCoupons) {
      const disc = c.DiscountType === 'Percent' ? `${c.DiscountValue}% OFF` : `₹${c.DiscountValue} OFF`;
      text += `🏷 <code>${c.CouponCode}</code> — ${disc}`;
      if (c.MinimumOrder) text += ` (Min. order ₹${c.MinimumOrder})`;
      text += '\n';
    }
  } else {
    text += 'No active offers right now. Follow our channel for updates!';
  }

  await ctx.reply(text, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([[{ text: '🛍 Shop Now', callback_data: 'menu_browse' }, { text: '🔙 Main Menu', callback_data: 'menu_main' }]]),
  });
}

// ── Show support info ─────────────────────────────────────────────────────────
async function showSupport(ctx) {
  await ctx.answerCbQuery().catch(() => {});

  const text = [
    `💬 <b>Support</b>`,
    ``,
    `Need help? We're here for you!`,
    ``,
    `📞 Contact Support: @${config.telegram.supportUsername}`,
    `⏱ Response Time: Usually within 1-2 hours`,
    ``,
    `📦 <b>Order Issues?</b>`,
    `Use /myorders to check your order status.`,
    ``,
    `💳 <b>Payment Issues?</b>`,
    `Send your Transaction ID and Order ID to support.`,
  ].join('\n');

  await ctx.reply(text, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([[{ text: '🔙 Main Menu', callback_data: 'menu_main' }]]),
  });
}

module.exports = {
  showCategories,
  showCategoryProducts,
  showProduct,
  showFeatured,
  showOffers,
  showSupport,
};
