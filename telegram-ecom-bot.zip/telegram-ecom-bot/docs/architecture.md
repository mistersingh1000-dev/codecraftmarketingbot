# System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    TELEGRAM ECOMMERCE BOT                    │
└─────────────────────────────────────────────────────────────┘

  USERS                     BOT SERVER                   DATA
  ─────                     ──────────                   ────

  [Customer]                                         [Google Sheets]
     │                                                      │
     │ /start, browse,                                      │
     │ buy click                                            │
     ▼                                                      │
  [Telegram API] ────────► [Express + Telegraf]  ◄──────────┤
                                    │                        │
                                    │                  Products Sheet
                           ┌────────┴─────────┐       Orders Sheet
                           │                  │       Coupons Sheet
                      [Shop Handler]    [Order Handler]  Settings Sheet
                           │                  │
                    Show categories    Generate Order ID
                    Show products      Create order row
                    Show plans         Generate payment link
                           │                  │
                           └────────┬─────────┘
                                    │
                           [Payment Service]
                                    │
                          ┌─────────▼──────────┐
                          │  SuperProfile API   │
                          │  (or UPI fallback)  │
                          └─────────┬──────────┘
                                    │
                          [Payment Webhook]
                                    │
                          Payment confirmed?
                                    │
                    ┌───────────────┼───────────────┐
                    │               │               │
             [Instant Product] [Manual Product] [Failed]
                    │               │               │
             [Delivery Service] [Admin Notified]  [User notified]
                    │               │
           ┌────────┴────────┐   Admin clicks
           │                 │   ✅ Approve
      TelegramFile      DriveLink  ❌ Reject
      ChannelInvite     TextLicense ⏳ Waiting
           │                 │   📦 Delivered
           └────────┬────────┘       │
                    │                │
              [Customer]      [Customer notified]
              receives              │
              product        [If Delivered →
                              Trigger delivery]


  ADMIN FLOW
  ──────────

  [Admin]
     │
     │ /admin, /orders, /stats
     ▼
  [Admin Commands]
     │
     ├── View pending orders
     ├── Approve/Reject/Waiting/Delivered
     ├── Broadcast message
     ├── View statistics
     └── Refresh cache

  GOOGLE SHEETS DATA FLOW
  ───────────────────────

  Admin edits Google Sheets
          │
          ▼
  Bot reads on next request
  (cached 5 min, or manual refresh)
          │
          ▼
  Products/prices/settings
  updated instantly
```

## Module Dependency Graph

```
index.js
  └── bot.js
        ├── commands/start.js
        │     └── database/sheets.js
        ├── commands/admin.js
        │     ├── database/sheets.js
        │     ├── services/delivery.js
        │     └── utils/helpers.js
        ├── handlers/shop.js
        │     ├── database/sheets.js
        │     └── utils/helpers.js
        ├── handlers/orders.js
        │     ├── database/sheets.js
        │     ├── services/payment.js
        │     ├── services/delivery.js
        │     └── utils/helpers.js
        └── middlewares/auth.js
              └── config/config.js

webhooks/webhook.js
  ├── database/sheets.js
  ├── services/delivery.js
  ├── services/payment.js
  └── utils/helpers.js
```
