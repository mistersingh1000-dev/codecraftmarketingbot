# Google Sheets Database Template
# Telegram Ecommerce Bot — Complete Data Dictionary

---

## HOW TO SET UP YOUR GOOGLE SHEET

1. Create a new Google Sheet at sheets.google.com
2. Create 6 tabs (sheets) with these EXACT names:
   - Products
   - Orders
   - Admins
   - Coupons
   - Settings
   - Analytics

3. Copy the headers and example rows below into each tab.
4. Share the sheet with your service account email (Editor access).

---

## SHEET 1: Products

### Column Headers (Row 1):
ProductID | Category | ProductName | ShortDescription | FullDescription | ProductType | PlanName | Price | Currency | ImageFileID | DeliveryMethod | DeliveryLink | StockStatus | AvailableQty | AutoDelivery | ButtonLabel | PaymentType | Tags | FeaturedProduct | ActiveStatus | CreatedDate

### Column Explanations:

| Column | Type | Description | Allowed Values |
|--------|------|-------------|----------------|
| ProductID | Text | Unique product identifier | P001, P002... |
| Category | Text | Product category name | Any text |
| ProductName | Text | Display name of the product | Any text |
| ShortDescription | Text | 1-2 line teaser shown in list | Any text |
| FullDescription | Text | Full product description | Any text |
| ProductType | Text | Delivery type | Instant / ManualApproval |
| PlanName | Text | Comma-separated plan names | e.g. "1 Month,3 Month,6 Month" |
| Price | Text | Comma-separated prices (match plans) | e.g. "299,699,1199" |
| Currency | Text | Currency code | INR |
| ImageFileID | Text | Telegram file_id for product image | Get via /getfileid command |
| DeliveryMethod | Text | How the product is delivered | TelegramFile / DriveLink / ChannelInvite / TextLicense / ManualDelivery |
| DeliveryLink | Text | URL, invite link, or license key | URL or text |
| StockStatus | Text | Current availability | Available / OutOfStock / Limited |
| AvailableQty | Number | Stock quantity (0 = unlimited) | 0, 10, 50... |
| AutoDelivery | Boolean | Auto-deliver after payment? | TRUE / FALSE |
| ButtonLabel | Text | Custom button text override | "Buy Now" or leave blank |
| PaymentType | Text | Payment gateway to use | SuperProfile / UPI / Manual |
| Tags | Text | Product tags for search/filter | "reels,viral,social media" |
| FeaturedProduct | Boolean | Show in Best Sellers? | TRUE / FALSE |
| ActiveStatus | Boolean | Is product visible in bot? | TRUE / FALSE |
| CreatedDate | Date | When product was added | YYYY-MM-DD |

### Example Data Rows:

Row 2 (Instant delivery — ZIP/file):
P001 | Reels Bundles | Viral Reels Mega Pack | 500+ viral reels for Instagram & TikTok | Get 500+ trending viral reels optimized for maximum reach. Includes hooks, transitions, audio sync guides. Works for all niches. | Instant | Starter,Pro,Ultimate | 99,299,999 | INR | AgACAgIAAxkBAAI... | TelegramFile |  | Available | 0 | TRUE | Buy Now | SuperProfile | reels,viral,instagram,content | TRUE | TRUE | 2024-01-15

Row 3 (Manual approval — subscription):
P002 | Subscriptions | Canva Pro Subscription | Full Canva Pro access — shared account | Get full Canva Pro access with all premium templates, brand kit, 100GB storage, and more. Shared account, managed by our team. | ManualApproval | 1 Month,3 Month,6 Month | 299,799,1399 | INR | AgACAgIAAxkBAAI... | TextLicense |  | Available | 5 | FALSE | Subscribe | SuperProfile | canva,design,subscription | TRUE | TRUE | 2024-01-15

Row 4 (Instant — Course):
P003 | Courses | Facebook Ads Mastery Course | Complete FB & Instagram ads course | Master Facebook and Instagram advertising from scratch. Includes 40+ video lessons, swipe files, ad templates, and lifetime updates. | Instant | Basic,Premium | 499,999 | INR | AgACAgIAAxkBAAI... | DriveLink | https://drive.google.com/file/d/YOUR_FILE_ID/view | Available | 0 | TRUE | Buy Now | SuperProfile | facebook,ads,course,marketing | TRUE | TRUE | 2024-01-15

Row 5 (Instant — Channel):
P004 | Premium Channels | Marketing Masterclass Channel | Access to private Telegram channel | Lifetime access to our premium Telegram channel with daily marketing strategies, case studies, and resources. | Instant | Lifetime | 199 | INR | AgACAgIAAxkBAAI... | ChannelInvite | https://t.me/joinchat/YOUR_INVITE_LINK | Available | 0 | TRUE | Join Channel | SuperProfile | telegram,channel,marketing | FALSE | TRUE | 2024-01-15

Row 6 (Manual — Premium account):
P005 | Subscriptions | ChatGPT Plus Account | Shared ChatGPT Plus access | Shared ChatGPT Plus account with GPT-4 access, DALL-E 3, advanced data analysis, and priority speed. | ManualApproval | 1 Month | 999 | INR |  | TextLicense |  | Limited | 3 | FALSE | Buy Now | SuperProfile | chatgpt,ai,gpt4 | FALSE | TRUE | 2024-01-15

Row 7 (Instant — Templates):
P006 | Templates | Instagram Growth Templates | 100 plug-and-play Canva templates | 100 fully editable Canva templates for Instagram growth. Stories, posts, reels covers, highlights. Instant download. | Instant | Standard | 149 | INR | AgACAgIAAxkBAAI... | DriveLink | https://drive.google.com/file/d/YOUR_FILE_ID/view | Available | 0 | TRUE | Download Now | SuperProfile | templates,canva,instagram | FALSE | TRUE | 2024-01-15

Row 8 (Out of stock example):
P007 | Subscriptions | Netflix Premium (4K) | 4K Netflix shared account | Shared Netflix Premium account with 4K UHD access. | ManualApproval | 1 Month | 199 | INR |  | TextLicense |  | OutOfStock | 0 | FALSE | Buy Now | SuperProfile | netflix,streaming | FALSE | TRUE | 2024-01-15

---

## SHEET 2: Orders

### Column Headers (Row 1):
OrderID | TelegramUserID | Username | FullName | ProductID | ProductName | PlanName | Price | PaymentStatus | OrderStatus | TransactionID | PaymentLink | DeliveryStatus | AdminNotes | CreatedAt | UpdatedAt

### Column Explanations:

| Column | Description | Auto/Manual |
|--------|-------------|-------------|
| OrderID | Unique order ID (format: ORD-timestamp-random) | Auto |
| TelegramUserID | Telegram user's numeric ID | Auto |
| Username | Telegram @username (may be empty) | Auto |
| FullName | User's Telegram display name | Auto |
| ProductID | Reference to Products sheet | Auto |
| ProductName | Copy of product name at time of order | Auto |
| PlanName | Which plan was purchased | Auto |
| Price | Final price paid | Auto |
| PaymentStatus | Pending / Paid / Failed / Refunded | Auto |
| OrderStatus | Pending / Approved / Rejected / Waiting / Delivered / Cancelled | Auto/Admin |
| TransactionID | Payment gateway transaction ID | Auto |
| PaymentLink | The payment URL generated | Auto |
| DeliveryStatus | Pending / Delivered | Auto |
| AdminNotes | Notes added by admin | Admin |
| CreatedAt | Order creation timestamp | Auto |
| UpdatedAt | Last update timestamp | Auto |

### Example Data:
ORD-1705312000000-427 | 123456789 | johndoe | John Doe | P001 | Viral Reels Mega Pack | Pro | 299 | Paid | Delivered |  |  | Delivered |  | 2024-01-15 10:30:00 | 2024-01-15 10:30:45

ORD-1705313000000-891 | 987654321 | janesmith | Jane Smith | P002 | Canva Pro Subscription | 1 Month | 299 | Paid | Pending |  |  | Pending | Waiting for account slot | 2024-01-15 11:00:00 | 2024-01-15 11:00:00

---

## SHEET 3: Admins

### Column Headers (Row 1):
AdminID | AdminUsername | Role | Permissions | Status

### Example Data:
123456789 | yourusername | SuperAdmin | all | Active
987654321 | secondadmin | Manager | orders,products | Active

---

## SHEET 4: Coupons

### Column Headers (Row 1):
CouponCode | DiscountType | DiscountValue | MinimumOrder | ExpiryDate | UsageLimit | Status

### Column Explanations:
| Column | Description | Values |
|--------|-------------|--------|
| CouponCode | The code users enter | SAVE20, FLAT50, etc. |
| DiscountType | Type of discount | Percent / Flat |
| DiscountValue | Amount of discount | 20 (= 20% or ₹20 depending on type) |
| MinimumOrder | Minimum order amount for coupon | 0, 199, 499... |
| ExpiryDate | Coupon expiry date | YYYY-MM-DD |
| UsageLimit | Max total uses (0 = unlimited) | 0, 10, 100... |
| Status | Is coupon active? | Active / Inactive |

### Example Data:
SAVE20 | Percent | 20 | 199 | 2024-12-31 | 100 | Active
FLAT50 | Flat | 50 | 299 | 2024-06-30 | 50 | Active
NEWUSER | Percent | 15 | 0 | 2024-12-31 | 0 | Active

---

## SHEET 5: Settings

### Column Headers (Row 1):
SettingName | SettingValue | Description

### Required Settings:

| SettingName | Example Value | Description |
|-------------|---------------|-------------|
| welcome_message | Welcome {name}! 🛍 Shop digital products | Bot welcome message ({name} = user's name) |
| banner_file_id | AgACAgIAAxkBAAI... | Telegram file_id of welcome banner image |
| upi_id | yourname@paytm | UPI ID for manual payment |
| store_name | Digital Products Store | Your store display name |
| support_message | Contact @support for help | Support instructions |

### Example Data:
welcome_message | Welcome {name}! 👋 Explore our premium digital products. | Shown on /start
banner_file_id |  | Leave blank if no banner
upi_id | yourstore@upi | Used in UPI payment links
store_name | Digital Products Store | Store branding
support_message | Contact @yoursupport for any help! | Support footer text

---

## SHEET 6: Analytics

### Column Headers (Row 1):
Date | TotalOrders | TotalRevenue | PendingOrders | DeliveredOrders | NewUsers

### Example Data:
2024-01-15 | 12 | 3450 | 2 | 10 | 8
2024-01-16 | 7 | 1890 | 1 | 6 | 4
2024-01-17 | 15 | 5200 | 3 | 12 | 11

---

## IMPORTANT NOTES

### Adding New Products:
1. Open the Products sheet
2. Add a new row with all required columns
3. Set ActiveStatus = TRUE to make it visible
4. The bot reads data dynamically — no restart needed!

### Updating Prices:
1. Edit the Price column directly in Google Sheets
2. Bot cache refreshes every 5 minutes (configurable via CACHE_TTL)
3. Or have admin run /admin → Refresh Cache for immediate update

### Getting Product Images:
1. Upload the image to your bot (or forward from somewhere)
2. Bot will reply with the file_id if you're an admin
3. Copy the file_id into the ImageFileID column
4. Bot will automatically show the image on product pages

### Managing Stock:
- Set StockStatus = OutOfStock to disable purchase button
- Set StockStatus = Limited to show 🔥 badge
- Set StockStatus = Available for normal display
